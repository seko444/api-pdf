from fastapi import FastAPI, Form
from fastapi.responses import StreamingResponse
from fpdf import FPDF
from io import BytesIO

app = FastAPI()

@app.post("/generar-pdf/")
async def generar_pdf(
    nombre: str = Form(...),
    email: str = Form(...),
    tipo: str = Form(...),
    descripcion: str = Form(...),
    precio: str = Form(...),
):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    pdf.cell(200, 10, txt="Resumen de Cotización", ln=True, align="C")
    pdf.ln(10)
    pdf.cell(200, 10, txt=f"Nombre: {nombre}", ln=True)
    pdf.cell(200, 10, txt=f"Email: {email}", ln=True)
    pdf.cell(200, 10, txt=f"Tipo de Servicio: {tipo}", ln=True)
    pdf.multi_cell(0, 10, txt=f"Descripción: {descripcion}")
    pdf.cell(200, 10, txt=f"Precio Estimado: {precio}", ln=True)

    pdf_bytes = BytesIO()
    pdf.output(pdf_bytes)
    pdf_bytes.seek(0)

    return StreamingResponse(pdf_bytes, media_type="application/pdf", headers={
        "Content-Disposition": f"inline; filename=cotizacion.pdf"
    })
